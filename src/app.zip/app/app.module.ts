import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { StarRatingComponent } from './component/star-rating/star-rating.component';
import { ProgressBarComponent } from './component/progress-bar/progress-bar.component';
import { GotoTopComponent } from './component/goto-top/goto-top.component';
import { TruncatePipe } from './pipes/truncate.pipe';
import { CreditCardFormaterPipe } from './pipes/credit-card-formater.pipe';
import { FlattenPipe } from './pipes/flatten.pipe';
import { DebounceClickDirective } from './directive/debounce-click.directive';
import { QuoteComponent } from './component/quote/quote.component';
import { FilterTermPipe } from './pipes/filter-term.pipe';



@NgModule({
  declarations: [
    AppComponent,
    StarRatingComponent,
    ProgressBarComponent,
    GotoTopComponent,
    TruncatePipe,
    CreditCardFormaterPipe,
    FlattenPipe,
    DebounceClickDirective,
    QuoteComponent,
    FilterTermPipe,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
