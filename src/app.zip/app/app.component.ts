import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = '100days-angular';

  public flattenData = [2,[3],6,6,[8,[3,2],6],7];
  public modify():void{
    this.flattenData.push([1,[6,7,8,4],5])
  }
  public reassign():void{
    this.flattenData =[...this.flattenData]
  }
  public log(){
    console.log("debounceClick")
  }
}
