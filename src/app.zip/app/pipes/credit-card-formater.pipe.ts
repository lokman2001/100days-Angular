import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'creditCardFormater'
})
export class CreditCardFormaterPipe implements PipeTransform {

  transform(cardNumber :string): string  {
    if (!this.hasCorrectLength){
      return "invalid card number."
    }
    if(!this.isAllNumber){
      return "invalid characters."
    }
    return this.formatCardNumber(cardNumber);
  }
  private isAllNumber(cardNumber : string):boolean{
    const stringNumber = ['0','1','2','3','4','5','6','7','8','9']
    const totalValidNumber = cardNumber.split('').filter((char)=> stringNumber.includes(char)).length
    return totalValidNumber === cardNumber.length;
  }
  private hasCorrectLength(cardNumber:string):boolean{
    const standardCreditCardLength = 16
    if(cardNumber.length === standardCreditCardLength){
      return true
    }
    return false;
  }
  private formatCardNumber(cardNumber:string): string {
    return cardNumber
    .replace(/\s+/g, '')
    .match(/.{1,4}/g)!
    .join('-');
  }

}
