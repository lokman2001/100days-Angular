import { FilterTermPipe } from './filter-term.pipe';

describe('FilterTermPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterTermPipe();
    expect(pipe).toBeTruthy();
  });
});
