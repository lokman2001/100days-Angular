import { FlattenPipe } from './flatten.pipe';

describe('FlattenPipe', () => {
  it('create an instance', () => {
    const pipe = new FlattenPipe();
    expect(pipe).toBeTruthy();
  });
});
