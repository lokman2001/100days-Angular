import { Component, OnInit } from '@angular/core';
import { Input } from '@angular/core';

@Component({
  selector: 'app-star-rating',
  templateUrl: './star-rating.component.html',
  styleUrls: ['./star-rating.component.scss']
})
export class StarRatingComponent {

  @Input() public rating = 5;
  

  public get fullStar():number[]{
    const totalFullStar = Math.floor(this.rating)
    return Array(totalFullStar).fill(0);
  }

  public get halfStar():boolean{
    const isHalfStar = (this.rating - Math.floor(this.rating) >= 0.5 )&& this.rating !== 5;
    return isHalfStar;
  }
  public get emptyStar():number[]{
    const hightestRating = 5
    const totalEmptyStar = Math.floor(hightestRating - this.rating)
    return Array(totalEmptyStar).fill(0)
  }


}
